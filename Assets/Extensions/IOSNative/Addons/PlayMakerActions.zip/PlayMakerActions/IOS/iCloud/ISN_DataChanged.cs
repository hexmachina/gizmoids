﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - iCloud")]
	public class ISN_DataChanged : FsmStateAction {
	
		public FsmEvent successEvent;

		public FsmString key;
		public FsmString value;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
						
			iCloudManager.instance.addEventListener (iCloudManager.CLOUD_DATA_CHANGED, OnDataChanged);
			iCloudManager.instance.setString (key.Value, value.Value);
		}
		
		private void OnDataChanged() {
			iCloudManager.instance.removeEventListener (iCloudManager.CLOUD_DATA_CHANGED, OnDataChanged);

			Fsm.Event(successEvent);
			Finish();
		}
	}
}
