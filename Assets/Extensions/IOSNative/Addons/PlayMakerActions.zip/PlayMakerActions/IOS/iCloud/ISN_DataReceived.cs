﻿using UnityEngine;
using UnionAssets.FLE;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - iCloud")]
	public class ISN_DataReceived : FsmStateAction {
		
		public FsmEvent successEvent;

		public FsmString key;

		public FsmString data_key;
		public FsmString data_stringValue;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			iCloudManager.instance.addEventListener (iCloudManager.CLOUD_DATA_RECEIVE, OnDataReceive);
			iCloudManager.instance.requestDataForKey (key.Value);
		}

		private void OnDataReceive(CEvent e) {
			iCloudData data = e.data as iCloudData;
			iCloudManager.instance.removeEventListener (iCloudManager.CLOUD_DATA_RECEIVE, OnDataReceive);

			if (data.IsEmpty) {
				this.data_key = data.key;
				this.data_stringValue = "";
			}
			else {
				this.data_key = data.key;
				this.data_stringValue = data.stringValue;
			}

			Fsm.Event(successEvent);
			Finish();
		}
	}
}
