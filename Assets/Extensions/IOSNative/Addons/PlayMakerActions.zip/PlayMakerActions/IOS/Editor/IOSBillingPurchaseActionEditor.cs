using UnityEngine;
using System.Collections;
using UnityEditor;
using HutongGames.PlayMaker.Actions;
using HutongGames.PlayMakerEditor;

[CustomActionEditor(typeof(ISN_PurchaseAction))]
public class IOSBillingPurchaseActionEditor : CustomActionEditor {

	private int index = 0;

	public override void OnEnable() {
		ISN_PurchaseAction action = target as ISN_PurchaseAction;
		if(IOSNativeSettings.Instance.InAppProducts.Contains(action.ProductID)) {
			index = IOSNativeSettings.Instance.InAppProducts.IndexOf(action.ProductID);
		}

	}
	
	// Update is called once per frame
	public override bool OnGUI() {
		// If you need to reference the action directly:
		ISN_PurchaseAction action = target as ISN_PurchaseAction;
		
		// You can draw the full default inspector.
		

		bool isDirty = DrawDefaultInspector();
		
		// Or draw individual controls
		
		GUILayout.Label("Choose in-app product.", EditorStyles.label);
		GUILayout.Label("Yuo can purchase only product with is defined under ", EditorStyles.label);
		GUILayout.Label("Window -> IOS Native -> Settings:", EditorStyles.label);

		if(IOSNativeSettings.Instance.InAppProducts.Count == 0) {
			EditorGUILayout.HelpBox("No producs added", MessageType.Warning);

			EditorGUILayout.BeginHorizontal();
			EditorGUILayout.Space();
			if(GUILayout.Button("Add In-App Producs",  GUILayout.Width(120))) {
				IOSNativeSettings.Instance.ShowStoreKitParams = true;
				Selection.activeObject = IOSNativeSettings.Instance;
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();
		} else {
			index = EditorGUILayout.Popup(index, IOSNativeSettings.Instance.InAppProducts.ToArray());
			action.ProductID = IOSNativeSettings.Instance.InAppProducts[index];
		}

		
		return isDirty || GUI.changed;
	}
}
