﻿using UnityEngine;
using UnionAssets.FLE;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Pop-ups")]
	[Tooltip("Init Game Cneter. Best practice to do this on appplicaton start")]
	public class ISN_DialogPopUpAction : FsmStateAction {


		public FsmString title;
		public FsmString message;

		public FsmString yes;
		public FsmString no;

		public FsmEvent yesEvent;
		public FsmEvent noEvent;

		[Tooltip("Result will be fired in unity Editor")]
		public IOSDialogResult ResultInEditor = IOSDialogResult.YES;

		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				ParseResult(ResultInEditor);
				return;
			}
			//v.stringValue

			IOSDialog rate = IOSDialog.Create(title.Value, message.Value, yes.Value, no.Value);

			rate.addEventListener(BaseEvent.COMPLETE, OnComplete);
			
		}


		public override void Reset() {
			base.Reset();

			title =  "Dialog title";
			message   = "Dialog message";
			yes = "Okay";
			no = "No";

		}


		private void OnComplete(CEvent e) {
			
			//romoving listner
			(e.dispatcher as IOSDialog).removeEventListener(BaseEvent.COMPLETE, OnComplete);
			
			//parsing result
			ParseResult((IOSDialogResult)e.data);
		}


		private void ParseResult(IOSDialogResult res) {
			switch(res) {
			case IOSDialogResult.YES:
				Fsm.Event(yesEvent);
				break;
			case IOSDialogResult.NO:
				Fsm.Event(noEvent);
				break;
				
			}
			
			Finish();
		}
		
	}
}


