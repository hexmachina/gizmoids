using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Social")]
	public class ISN_TwitterPostScreenShot : FsmStateAction {

		public FsmString message;


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}


			IOSSocialManager.instance.addEventListener(IOSSocialManager.TWITTER_POST_SUCCESS, OnPostSuccses);
			IOSSocialManager.instance.addEventListener(IOSSocialManager.TWITTER_POST_FAILED, OnPostFailed);

			ISN_ScreehSotPostTask task  = new GameObject("ScreehSotPostTask").AddComponent<ISN_ScreehSotPostTask>();
			task.type = "TW";
			task.msg = message.Value;

		}

		public override void Reset() {
			base.Reset();
			message   = "Message Text";
			
		}

		private void RemoveEvents() {
			IOSSocialManager.instance.removeEventListener(IOSSocialManager.TWITTER_POST_SUCCESS, OnPostSuccses);
			IOSSocialManager.instance.removeEventListener(IOSSocialManager.TWITTER_POST_FAILED, OnPostFailed);
		}



		private void OnPostFailed() {
			RemoveEvents();
			Fsm.Event(failEvent);
			Finish();
		}
		
		private void OnPostSuccses() {
			RemoveEvents();
			Fsm.Event(successEvent);
			Finish();
		}

	}
}


